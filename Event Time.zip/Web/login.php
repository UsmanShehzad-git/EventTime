<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eventtime-login</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <!-- Login Container -->
    <div class="login-container">
        <!-- Side Vector Image -->
        <div class="login-image"></div>

        <!-- Login Form -->
        <div class="login-form">
            <h2>Login</h2>
            <form action="php/login.php" method="post">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" placeholder="Enter your email" required>

                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="Enter your password" required>

                <button type="submit">Login</button>

                <div class="forgot-password">
                    <a href="#">Forgot Password?</a>
                    <p style="color: #000;">If you don't have an account <a href="signup.php">Signup</a></p>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
