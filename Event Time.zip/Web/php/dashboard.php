<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

// Display the dashboard
header("Location: index.html");
echo "<h1>Welcome, " . htmlspecialchars($_SESSION['email']) . "!</h1>";
echo "<a href='logout.php'>Logout</a>";
?>
