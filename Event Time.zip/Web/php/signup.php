<?php
// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $fullName = $_POST['name'] ?? null;
    $email = $_POST['email'] ?? null;
    $password = $_POST['password'] ?? null;
    $confirmPassword = $_POST['confirm_password'] ?? null;

    // Validate input data
    if (empty($fullName) || empty($email) || empty($password) || empty($confirmPassword)) {
        die("All fields are required.");
    }

    $errors = [];

    // Full Name Validation
    $name = trim($_POST['name']);
    if (empty($name)) {
        $errors['name'] = 'Full name is required.';
    }
    // Email Validation
    $email = trim($_POST['email']);
    if (empty($email)) {
        $errors['email'] = 'Email is required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Enter a valid email address.';
    }
    $password = trim($_POST['password']);
    if (empty($password)) {
        $errors['password'] = 'Password is required.';
    } elseif (strlen($password) < 6) {
        $errors['password'] = 'Password must be at least 6 characters.';
    }
    $confirm_password = trim($_POST['confirm_password']);
    if ($confirm_password !== $password) {
        $errors['confirm_password'] = 'Passwords do not match.';
    }
    // If no errors, proceed to process the data
    if (empty($errors)) {
        // Proceed to store user data in the database
        echo "Signup successful!";
    } else {
        // Show errors to the user
        foreach ($errors as $field => $error) {
            echo "<p>$field: $error</p>";
        }
    }

    if ($password !== $confirmPassword) {
        die("Passwords do not match.");
    }

    // Hash the password for secure storage
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    // Database connection parameters
    $host = 'localhost'; // Replace with your database host
    $db = 'local_event'; // Replace with your database name
    $user = 'root'; // Replace with your database username
    $pass = 'Mani$009'; // Replace with your database password
    $charset = 'utf8mb4';

    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";

    try {
        // Create a new PDO instance
        $pdo = new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);

        // Insert user data into the database
        $sql = "INSERT INTO signup (full_name, email, password_hash) VALUES (:full_name, :email, :password_hash)";
        $stmt = $pdo->prepare($sql);

        // Bind parameters
        $stmt->bindParam(':full_name', $fullName);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password_hash', $hashedPassword);

        // Execute the query
        $stmt->execute();

        header("Location: \Web\login.html");
        exit();
        
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) { // Duplicate entry error
            echo "Error: The email address is already registered.";
        } else {
            echo "Error: " . $e->getMessage();
        }
    }
} else {
    echo "Invalid request method.";
}
?>
