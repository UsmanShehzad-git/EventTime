<?php
// Database connection
$host = "localhost";
$username = "root";
$password = "Mani$009";
$dbname = "local_event";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve and sanitize form inputs
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';

    // Validate inputs
    if (empty($email) || empty($password)) {
        die("All fields are required.");
    }

    // Check user credentials
    $stmt = $conn->prepare("SELECT user_id, password_hash FROM signup WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($userId, $passwordHash);
        $stmt->fetch();

        // Verify the password
        if (password_verify($password, $passwordHash)) {
            // Start a session and set user session variables
            session_start();
            $_SESSION['user_id'] = $userId;
            $_SESSION['email'] = $email;

            // Redirect to a dashboard or home page after login
            header("Location: \Web\index.php");
            exit();
        } else {
            echo "Invalid email or password.";
        }
    } else {
        echo "Invalid email or password.";
    }

    $stmt->close();
}

$conn->close();
?>
