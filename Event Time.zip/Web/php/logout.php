<?php
session_destroy();
header("Location: \Web\login.php");
exit();
?>
