<?php
// Database connection settings
$servername = "localhost";
$username = "root";
$password = "Mani$009";
$dbname = "local_event";

// Connect to MySQL database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if delete_id is set
if (isset($_GET['delete_id'])) {
    $event_id = intval($_GET['delete_id']); // Sanitize input

    // Prepare and execute the delete statement
    $delete_sql = "DELETE FROM events WHERE id = ?";
    $stmt = $conn->prepare($delete_sql);
    $stmt->bind_param("i", $event_id);

    if ($stmt->execute()) {
        // Redirect back to the event management page
        header('Location: myevents.php');
        exit;
    } else {
        echo "Error deleting event: " . $conn->error;
    }

    $stmt->close();
} else {
    echo "Invalid request.";
}

$conn->close();
?>
