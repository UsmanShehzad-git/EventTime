<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Local Event Finder</title>
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="Resources/placeholder.png" type="image/x-icon">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
</head>

<body>
    <!-- Nav Bar Start  -->
    <div class="f1">
        <nav class="navbar">
            <div class="logo-img"><img src="Resources/placeholder.png" alt="Logo"></div>
            <div class="logo">EventTime</div>
            <form action="php/search.php" method="GET" style="display: flex; gap: 10px; align-items: center;">
            <input
                type="text"
                name="search"
                placeholder="Search..."
                style="padding: 8px; border-radius: 5px; border: 1px solid #ccc; width: 450px;"
                required
            />
            <button
                type="submit"
                style="background-color: white; color: #1d3557; padding: 8px 15px; border: none; border-radius: 5px; cursor: pointer;">
                Search
            </button>
        </form>
            <ul class="nav-links">
                <li><a href="index.html">Home</a></li>
                <li><a href="about.html">About</a></li>

            </ul>
            <?php
            session_start();
            ?>
            <div class="right">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <div>
                    <ul class="nav-links">
                    <li class="dropdown">
                    <a id="myevent" href="#events" class="dropbtn">Events</a>
                        <div class="dropdown-content">
                            <a href="myevents.php">My Events</a>
                        </div>
                            <li><a href="event_manage.php">Manage Events</a></li>
                        </li>
                    </ul>
                    </div>

                <!-- Show Logout if the user is logged in -->
                <li class="logout-btn"><a href="\Web\php\logout.php">Logout</a></li>
                <?php else: session_destroy(); ?>
                <!-- Show Login and Sign Up if the user is not logged in -->
                <li class="login-btn"><a href="login.php">Login</a></li>
                <li class="signup-btn"><a href="signup.php">Sign Up</a></li>
                <?php endif; ?>
            </div>
        </nav>
        <!-- Nav Bar End  -->
        <div class="main">
            <h2>Every moment is an event <br> waiting to happen .......</h2>
            <a href="explore_event.php">Explore Events</a>
        </div>
        <div class="num_bar">
            <div class="numbers-container">
                <div class="number-box">
                    <span class="number">200+</span>
                    <p>Events Organized</p>
                </div>
                <div class="number-box">
                    <span class="number">20+</span>
                    <p>Locations</p>
                </div>
                <div class="number-box">
                    <span class="number">4</span>
                    <p>Years of Experience</p>
                </div>
                <div class="number-box">
                    <span class="number">50+</span>
                    <p>Awards Won</p>
                </div>
            </div>
        </div>
    </div>

    <div class="main2">
        <!-- UpComing events Start -->
        <section class="upcoming-events">
            <h1>Upcoming Events</h1>
            <div class="events-container">
                <!-- Event Card 1 -->
                <div class="event-card event-1">
                    <div class="event-content">
                        <h2 class="event-title">Music Concert</h2>
                        <p class="event-date">Dec 15, 2024</p>
                        <a href="#" class="event-button">Read More</a>
                    </div>
                </div>
                <!-- Event Card 2 -->
                <div class="event-card event-2">
                    <div class="event-content">
                        <h2 class="event-title">Art Exhibition</h2>
                        <p class="event-date">Dec 20, 2024</p>
                        <a href="#" class="event-button">Read More</a>
                    </div>
                </div>
                <!-- Event Card 3 -->
                <div class="event-card event-3">
                    <div class="event-content">
                        <h2 class="event-title">Food Festival</h2>
                        <p class="event-date">Dec 25, 2024</p>
                        <a href="#" class="event-button">Read More</a>
                    </div>
                </div>
                <!-- Event Card 4 -->
                <div class="event-card event-4">
                    <div class="event-content">
                        <h2 class="event-title">Christmas Gala</h2>
                        <p class="event-date">Dec 28, 2024</p>
                        <a href="#" class="event-button">Read More</a>
                    </div>
                </div>
                <!-- Event Card 5 -->
                <div class="event-card event-5">
                    <div class="event-content">
                        <h2 class="event-title">Knight Party</h2>
                        <p class="event-date">Dec 31, 2024</p>
                        <a href="#" class="event-button">Read More</a>
                    </div>
                </div>
                <!-- Event Card 6 -->
                <div class="event-card event-6">
                    <div class="event-content">
                        <h2 class="event-title">Special Events</h2>
                        <p class="event-date">Jan 01, 2025</p>
                        <a href="#" class="event-button">Read More</a>
                    </div>
                </div>
            </div>

        </section>
        <!-- UpComing events end -->
    </div>
    <!-- How it work Section -->
    <section class="how-it-works">
        <div class="content-wrapper">
            <h2>How It Works?</h2>
            <p>Discover how Local Event makes finding and hosting events simple and efficient.</p>

            <div class="steps-container">
                <div class="step">
                    <div class="step-number">1</div>
                    <h3>Explore Events</h3>
                    <p>Search and browse through countless events tailored to your preferences and location.</p>
                </div>
                <div class="step">
                    <div class="step-number">2</div>
                    <h3>Choose & Book</h3>
                    <p>Select the event that excites you and book your spot instantly with secure payments.</p>
                </div>
                <div class="step">
                    <div class="step-number">3</div>
                    <h3>Attend & Enjoy</h3>
                    <p>Get your tickets, attend the event, and create unforgettable memories.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- How it work End -->

    <!-- Partnership Opportunities Section -->
    <div class="opportunities-section">
        <div class="content-wrapper">
            <h1>Discover Partnership Opportunities</h1>
            <p>Join us in creating memorable experiences with customized solutions to enhance your brand reach and
                engagement.</p>

            <!-- Opportunity Cards -->
            <div class="cards-container">
                <div class="card">
                    <div class="icon-container">
                        <i class="fas fa-lightbulb"></i>
                    </div>
                    <h3>Innovative Ideas</h3>
                    <p>Collaborate with us to unlock creative solutions tailored to your goals.</p>
                </div>
                <div class="card">
                    <div class="icon-container">
                        <i class="fas fa-users"></i>
                    </div>
                    <h3>Engagement Tools</h3>
                    <p>Leverage our tools to connect with your audience and maximize visibility.</p>
                </div>
                <div class="card">
                    <div class="icon-container">
                        <i class="fas fa-rocket"></i>
                    </div>
                    <h3>Market Reach</h3>
                    <p>Expand your brand's footprint with targeted strategies for growth.</p>
                </div>
                <div class="card">
                    <div class="icon-container">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <h3>Growth Insights</h3>
                    <p>Analyze trends and capitalize on opportunities to boost your presence.</p>
                </div>
            </div>

            <!-- Call-to-action Buttons -->
            <div class="cta-buttons">
                <a class="btn-primary" href="event_manage.php">Create Your Event</a>
                <button class="btn-secondary">Become a Partner</button>
            </div>
        </div>
    </div>
    <!-- Footer Section -->
    <footer class="footer">
        <div class="logo-section">
            <button class="join-free">Join For Free</button>
        </div>
        <div class="footer-links">
            <div class="about-sec">
                <h1>About</h1>
                <h5>Event Time is a cutting-edge platform designed to connect communities by showcasing events
                    tailored to their interests. From concerts and festivals to workshops and meetups, our mission is to
                    make event discovery seamless and accessible for everyone. Whether you're an organizer or an
                    attendee, we empower you to create, explore, and engage with memorable experiences in your area.
                </h5>
            </div>
            <div>
                <h4>Quick Links</h4>
                <p>Event Creation</p>
                <p>Community</p>
                <p>Partners</p>
            </div>
            <div>
                <h4>Resources</h4>
                <p>Help Center</p>
                <p>FAQs</p>
            </div>
            <div>
                <h4>Contact Us</h4>
                <p>Contact Info</p>
                <p>Feedback</p>
            </div>
            <div>
                <h4>Legal</h4>
                <p>Accessibility</p>
                <p>Terms</p>
            </div>
        </div>
    </footer>
</body>

</html>