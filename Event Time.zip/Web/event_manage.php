<?php
// Database connection settings
$servername = "localhost"; // Change if your DB server is on another host
$username = "root";        // Database username
$password = "Mani$009";    // Database password
$dbname = "local_event";   // Database name

// Connect to MySQL database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the user is logged in
    if (!isset($_SESSION['user_id'])) {
        die("Error: You must be logged in to create an event.");
    }

    // Retrieve user ID from the session
    $user_id = $_SESSION['user_id'];

    // Retrieve and sanitize form inputs
    $name = trim($_POST['name']);
    $event_date = trim($_POST['event_date']);
    $category = trim($_POST['category']);
    $description = trim($_POST['description']);
    $image_url = trim($_POST['image_url']);

    // Validate required fields
    if (empty($name) || empty($event_date) || empty($category)) {
        die("Error: Event name, date, and category are required fields.");
    }

    // Insert the event into the database
    $query = "INSERT INTO events (user_id, name, event_date, category, description, image_url) 
              VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);

    if (!$stmt) {
        die("Error: " . $conn->error);
    }

    $stmt->bind_param("isssss", $user_id, $name, $event_date, $category, $description, $image_url);

    if ($stmt->execute()) {
        echo "Event created successfully!";
        // Redirect to the events page to avoid resubmission on refresh
        header("Location: myevents.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close(); // Close the statement
}

if (!isset($_SESSION['user_id'])) {
    die("Error: User ID not found in the session.");
}
// echo "User ID from session: " . $_SESSION['user_id'] . "<br>";
$user_id = (int) $_SESSION['user_id'];


// Fetch all events for the user from the database
$sql = "SELECT * FROM events WHERE user_id = ? ORDER BY event_date DESC";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("i", $user_id);

if (!$stmt->execute()) {
    die("Error executing statement: " . $stmt->error);
}

$result = $stmt->get_result();

$stmt->close(); // Close the statement

$conn->close(); // Close the database connection

// Handle event deletion
if (isset($_GET['delete_id'])) {
    $event_id = $_GET['delete_id'];

    // Prepare DELETE query using prepared statements
    $delete_query = "DELETE FROM events WHERE id = ?";
    $stmt = $conn->prepare($delete_query);
    
    if (!$stmt) {
        die("Error: " . $conn->error);
    }
    
    $stmt->bind_param("i", $event_id);
    
    if ($stmt->execute()) {
        echo "<p style='color:green; text-align:center'>Event deleted successfully!</p>";
    } else {
        echo "<p style='color:red; text-align:center'>Error: " . $stmt->error . "</p>";
    }

    $stmt->close(); // Close the statement
}


?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <title>Event Manager</title>

</head>
<style>
    :root {
        --primary-color: #1d3557;
        --secondary-color: #fff;
        --optional-color: #f39c12;
    }

    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin: 0;
        padding: 0;
        background: #f4f4f9;
        pad color: #333;
    }

    .container {
        max-width: 800px;
        margin: 30px auto;
        padding: 20px;
        background: #fff;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        border-radius: 10px;
        padding-left: 30px;
        padding-right: 30px;
    }

    h1,
    h2 {
        text-align: center;
        color: #444;
        font-size:40px;
        font-weight:bold;
    }

    form {
        margin-bottom: 20px;
    }

    .form-group {
        margin-bottom: 15px;
        margin-left:80px;
        margin-right:80px;
    }

    .form-group label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
        color: #555;
    }

    .form-group input,
    .form-group textarea {
        width: 100%;
        padding: 12px;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-sizing: border-box;
        font-size: 14px;
    }

    .form-group button {
        background-color: #007BFF;
        color: white;
        border: none;
        padding: 12px 18px;
        cursor: pointer;
        border-radius: 5px;
        font-size: 16px;
        transition: background 0.3s ease;
    }

    .form-group button:hover {
        background-color: #0056b3;
    }

    .success {
        color: green;
        font-weight: bold;
        margin-bottom: 15px;
    }

    .error {
        color: red;
        font-weight: bold;
        margin-bottom: 15px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
        padding-left:30px;
    }

    table thead {
        background: var(--optional-color);
        color: #fff;
    }

    table th,
    table td {
        padding: 15px;
        text-align: left;
        border: 1px solid #ddd;
        font-size: 14px;
        word-wrap: break-word; /* Ensures text breaks within the cell */
        white-space: normal;   /* Allows text to wrap to the next line */
        max-width: 300px; 
    }

    table tbody tr:nth-child(odd) {
        background: #f9f9f9;
    }

    table tbody tr:hover {
        background: #f1f1f1;
    }

    table img {
        max-width: 100px;
        border-radius: 5px;
    }

    footer {
        text-align: center;
        margin-top: 30px;
        color: #777;
        font-size: 12px;
    }
    button{
        padding:10px 70px;
        border:none;
        color: var(--secondary-color);
        background: var(--primary-color);
        border-radius:10px;
        text-align: center;
        margin-left:6vw;
        cursor: pointer;
        transition: 0.3s all ease-in-out;
    }
    button:hover{
        background: var(--optional-color);
    }
    #icon{
       cursor: pointer;
    }
    #name{
        text-decoration: none;
        color: #000;
        cursor: pointer;
    }
    #name:hover{
        color: var(--optional-color);
    }
</style>

<body>
    <h1>Event Manager</h1>

    <!-- Event Form -->
    <form method="POST" action="">
        <div class="form-group">
            <label for="name">Event Name:</label>
            <input type="text" id="name" name="name" required>
        </div>
        <div class="form-group">
            <label for="event_date">Event Date:</label>
            <input type="date" id="event_date" name="event_date" required>
        </div>
        <div class="form-group">
            <label for="category">Event Category:</label>
            <input type="text" id="category" name="category" required>
        </div>
        <div class="form-group">
            <label for="description">Event Description:</label>
            <textarea id="description" name="description" rows="4" required></textarea>
        </div>
        <div class="form-group">
            <label for="image_url">Event Image URL:</label>
            <input type="text" id="image_url" name="image_url">
        </div>
        <button type="submit">Add Event</button>
    </form>

    <h2>Upcoming Event List</h2>

    <!-- Event Table -->
    <?php if ($result->num_rows > 0): ?>
    <table>
        <thead>
            <tr>
                <th>Event Name</th>
                <th>Event Date</th>
                <th>Category</th>
                <th>Description</th>
                <th>Image</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td>
                    <a id="name" href="event_detail.php?event_id=<?php echo htmlspecialchars($row['id']); ?> ">
                         <?php echo htmlspecialchars($row['name']); ?>
                    </a>
                </td>
                <td>
                    <?php echo htmlspecialchars($row['event_date']); ?>
                </td>
                <td>
                    <?php echo htmlspecialchars($row['category']); ?>
                </td>
                <td>
                    <?php echo htmlspecialchars($row['description']); ?>
                </td>
                <td>
                    <?php if (!empty($row['image_url'])): ?>
                    <img src="<?php echo htmlspecialchars($row['image_url']); ?>" alt="Event Image" width="100">
                    <?php else: ?>
                    No Image
                    <?php endif; ?>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    <?php else: ?>
    <p style="font-size: 1.5rem; text-align:center; margin-top: 70px;">No events found for your account.</p>
    <?php endif; ?>

</body>

</html>