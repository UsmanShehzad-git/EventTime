<?php
// Database connection settings
$servername = "localhost"; // Change if your DB server is on another host
$username = "root";        // Database username
$password = "Mani$009";            // Database password
$dbname = "local_event";      // Database name

// Connect to MySQL database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $event_date = $_POST['event_date'];
    $category = $_POST['category'];
    $description = $_POST['description'];
    $image_url = $_POST['image_url'];

    // Insert event data into the database
    $sql = "INSERT INTO events (name, event_date, category, description, image_url)
            VALUES ('$name', '$event_date', '$category', '$description', '$image_url')";

    if ($conn->query($sql) === TRUE) {
        echo "<p style='color:green;'>Event added successfully!</p>";
    } else {
        echo "<p style='color:red;'>Error: " . $sql . "<br>" . $conn->error . "</p>";
    }
}

// Fetch all events from the database
$sql = "SELECT * FROM events ORDER BY event_date DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Manager</title>

</head>
<style>
    :root {
        --primary-color: #1d3557;
        --secondary-color: #fff;
        --optional-color: #f39c12;
    }

    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin: 0;
        padding: 0;
        background: #f4f4f9;
        pad color: #333;
    }

    .container {
        max-width: 800px;
        margin: 30px auto;
        padding: 20px;
        background: #fff;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        border-radius: 10px;
        padding-left: 30px;
        padding-right: 30px;
    }

    h1 {
        text-align: center;
        color: #444;
        font-size:40px;
        font-weight:bold;
    }
    h2{
        text-align: center;
        color: #555;
        font-size:15px; 
        opacity: 70%;
    }

    .success {
        color: green;
        font-weight: bold;
        margin-bottom: 15px;
    }

    .error {
        color: red;
        font-weight: bold;
        margin-bottom: 15px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    table thead {
        background: var(--primary-color);
        color: #fff;
    }

    table th,
    table td {
        padding: 15px;
        text-align: left;
        border: 1px solid #ddd;
        font-size: 14px;
        word-wrap: break-word; /* Ensures text breaks within the cell */
        white-space: normal;   /* Allows text to wrap to the next line */
        max-width: 300px; 
    }

    table tbody tr:nth-child(odd) {
        background: #f9f9f9;
    }

    table tbody tr:hover {
        background: #f1f1f1;
    }

    table img {
        max-width: 100px;
        border-radius: 5px;
    }

    footer {
        text-align: center;
        margin-top: 30px;
        color: #777;
        font-size: 12px;
    }
    button{
        padding:10px 70px;
        border:none;
        color: var(--secondary-color);
        background: var(--primary-color);
        border-radius:10px;
        text-align: center;
        margin-left:6vw;
        cursor: pointer;
        transition: 0.3s all ease-in-out;
    }
    button:hover{
        background: var(--optional-color);
    }
</style>

<body>
    <h1>Explore Events</h1>
    <form action="php/search.php" method="GET" style="display: flex; align-items: center;">
            <input
                type="text"
                name="search"
                placeholder="Search..."
                style="padding: 12px 20px; border-radius: 5px; margin-left:32vw; border: 1px solid #ccc; width: 450px; margin-right:-5vw;"
                required
            />
            <button
                type="submit"
                style="background-color: white; color: #fff; background:#1d3557; padding: 12px 15px; border: none; border-radius: 5px; cursor: pointer;">
                Search
            </button>
        </form>

    <!-- Event Table -->
    <?php if ($result->num_rows > 0): ?>
    <table>
        <thead>
            <tr>
                <th>Event Name</th>
                <th>Event Date</th>
                <th>Category</th>
                <th>Description</th>
                <th>Image</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td>
                    <?php echo htmlspecialchars($row['name']); ?>
                </td>
                <td>
                    <?php echo htmlspecialchars($row['event_date']); ?>
                </td>
                <td>
                    <?php echo htmlspecialchars($row['category']); ?>
                </td>
                <td>
                    <?php echo htmlspecialchars($row['description']); ?>
                </td>
                <td>
                    <?php if (!empty($row['image_url'])): ?>
                    <img src="<?php echo htmlspecialchars($row['image_url']); ?>" alt="Event Image" width="100">
                    <?php else: ?>
                    No Image
                    <?php endif; ?>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    <?php else: ?>
    <p>No events found.</p>
    <?php endif; ?>

    <?php $conn->close(); ?>
</body>

</html>