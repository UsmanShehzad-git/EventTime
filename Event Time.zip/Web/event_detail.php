<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "Mani$009";
$dbname = "local_event";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the event ID from the URL
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch event details
$sql = "SELECT * FROM events WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$event = $result->fetch_assoc();

if (!$event) {
    die("Event not found.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Details</title>
    <style>
        :root {
        --primary-color: #1d3557;
        --secondary-color: #fff;
        --optional-color: #f39c12;
         }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f4f4f9;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 1000px;
            margin: 50px auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #333;
            text-align: center;
        }

        .event-detail {
            margin-top: 20px;
        }

        .event-detail img {
            max-width: 100%;
            width:500px;            
            display:flex;
            margin-left:18vw;
            border-radius: 8px;
            margin-bottom: 40px;
        }

        .event-detail p {
            font-size: 16px;
            margin: 10px 40px;

        }

        .back-link {
            display: inline-block;
            margin-top: 20px;
            margin-left:40px;
            text-decoration: none;
            color: #fff;
            background:var(--primary-color);
            padding: 10px 15px;
            border-radius: 5px;
            transition: 0.3s ease;
        }

        .back-link:hover {
            background: var(--optional-color);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1><?php echo htmlspecialchars($event['name']); ?></h1>
        <div class="event-detail">
            <img src="<?php echo htmlspecialchars($event['image_url']); ?>" alt="Event Image">
            <p><strong>Date:</strong> <?php echo htmlspecialchars($event['event_date']); ?></p>
            <p><strong>Category:</strong> <?php echo htmlspecialchars($event['category']); ?></p>
            <p><strong>Description:</strong> <?php echo nl2br(htmlspecialchars($event['description'])); ?></p>
        </div>
        <a href="event_manage.php" class="back-link">Back to Events</a>
    </div>
</body>
</html>
