<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eventtime-Signup</title>
    <link rel="stylesheet" href="signup.css">
</head>
<body>
    <!-- Signup Container -->
    <div class="signup-container">
        <!-- Side Vector Image -->
        <div class="signup-image"></div>

        <!-- Signup Form -->
        <div class="signup-form">
    <h2>Signup</h2>
    <form method="post" action="php/signup.php" id="signupForm">
        <label for="name">Full Name</label>
        <input type="text" id="name" name="name" placeholder="Enter your full name">
        <span class="error" id="nameError"></span>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" placeholder="Enter your email">
        <span class="error" id="emailError"></span>

        <label for="password">Password</label>
        <input type="password" id="password" name="password" placeholder="Enter your password">
        <span class="error" id="passwordError"></span>

        <label for="confirm-password">Confirm Password</label>
        <input type="password" id="confirm-password" name="confirm_password" placeholder="Confirm your password">
        <span class="error" id="confirmPasswordError"></span>

        <button type="submit">Signup</button>

        <div class="signin-link">
            Already have an account? <a href="login.html">Login here</a>
        </div>
    </form>
</div>

    </div>
    <script>
        document.getElementById('signupForm').addEventListener('submit', function (e) {
    let isValid = true;

    // Clear previous errors
    document.querySelectorAll('.error').forEach(error => error.textContent = '');

    // Validate Full Name
    const name = document.getElementById('name').value.trim();
    if (name === '') {
        document.getElementById('nameError').textContent = 'Full name is required.';
        isValid = false;
    }

    // Validate Email
    const email = document.getElementById('email').value.trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (email === '') {
        document.getElementById('emailError').textContent = 'Email is required.';
        isValid = false;
    } else if (!emailRegex.test(email)) {
        document.getElementById('emailError').textContent = 'Enter a valid email address.';
        isValid = false;
    }

    // Validate Password
    const password = document.getElementById('password').value.trim();
    if (password === '') {
        document.getElementById('passwordError').textContent = 'Password is required.';
        isValid = false;
    } else if (password.length < 6) {
        document.getElementById('passwordError').textContent = 'Password must be at least 6 characters.';
        isValid = false;
    }

    // Validate Confirm Password
    const confirmPassword = document.getElementById('confirm-password').value.trim();
    if (confirmPassword === '') {
        document.getElementById('confirmPasswordError').textContent = 'Confirm your password.';
        isValid = false;
    } else if (confirmPassword !== password) {
        document.getElementById('confirmPasswordError').textContent = 'Passwords do not match.';
        isValid = false;
    }

    // Prevent form submission if validation fails
    if (!isValid) {
        e.preventDefault();
    }
});

    </script>
</body>
</html>
